/* config.h.  Generated automatically by configure.  */
/* config.hin.  Generated automatically from configure.in by autoheader.  */

/* Define to empty if the keyword does not work.  */
/* #undef const */

/* Define if you have <unistd.h>.  */
#define HAVE_UNISTD_H 1

/* Define as __inline if that's what the C compiler calls it.  */
#define inline 

/* Define as the return type of signal handlers (int or void).  */
#define RETSIGTYPE void

/* Define to `unsigned' if <sys/types.h> doesn't define.  */
/* #undef size_t */

/* Define if the `S_IS*' macros in <sys/stat.h> do not work properly.  */
/* #undef STAT_MACROS_BROKEN */

/* Define if you have the ANSI C header files.  */
#define STDC_HEADERS 1

/* Define if the X Window System is missing or not being used.  */
/* #undef X_DISPLAY_MISSING */

/* Define if compiler can handle ANSI prototypes.  */
#define ANSI_C 1

/* Define if you want to use the Apollo Graphics Primitive Resource.  */
/* #undef APOLLO */

/* Define if you want to use the CGI terminal under SCO.  */
/* #undef CGI */

/* Define if you want to use libgrx20 with MSDOS/djgpp.  */
/* #undef DJSVGA */

/* Define if this system uses a 32-bit DOS extender (djgpp/emx).  */
/* #undef DOS32 */

/* Define if <errno.h> declares errno.  */
/* #undef EXTERN_ERRNO */

/* Define if you are using the GNU readline library.  */
/* #undef GNU_READLINE */

/* Define if your libplot.a is from GNU plotutils.  */
/* #undef GNU_PLOTUTILS */

/* Define if you want to use the GNU version of the Unix plot library.  */
/* #undef GNUGRAPH */

/* Define if you want to use the Apollo Graphics Primitive Resource (fixed-size window.  */
/* #undef GPR */

/* Define if you want to use a newer version of libgrx under MSDOS/djgpp.  */
/* #undef GRX21 */

/* Define if the C preprocessor understands ANSI stringification.  */
#define HAVE_STRINGIZE 1

/* Define if you have Thomas Boutell's gd library.  */
#define HAVE_LIBGD 1

/* Define if you have the png library.  */
/* #undef HAVE_LIBPNG */

/* Define if you want to use the IRIS terminal on IRIS4D series computers.  */
/* #undef IRIS */

/* Define if this is a Linux system with SuperVGA library.  */
/* #undef LINUXVGA */

/* Define if you want to use the MGR Window system.  */
/* #undef MGR */

/* Define if this is an MSDOS system with djgpp.  */
/* #undef MSDOS */

/* Define if you do not want to read .gnuplot in the current directory.  */
#define NOCWDRC 1

/* Define to the name of the distribution.  */
#define PACKAGE "gnuplot"

/* Define if you do have the popen and pclose functions.  */
#define PIPES 1

/* Define if you have the function prototypes.  */
#define PROTOTYPES 1

/* Define if you want to use the included readline function.  */
#define READLINE 1

/* Define if you want to use the Redwood Graphics Interface Protocol.  */
/* #undef RGIP */

/* Define as the type of the first argument to select.  */
#define SELECT_TYPE_ARG1 int

/* Define as the type of the second, third, and fourth argument to select.  */
#define SELECT_TYPE_ARG234 (fd_set *)

/* Define as the type of the fifth argument to select.  */
#define SELECT_TYPE_ARG5 (struct timeval *)

/* Define if you want to use the sunview terminal (sun).  */
/* #undef SUN */

/* Define if you want to use the unixpc terminal (ATT 3b1 or ATT 7300.  */
/* #undef UNIXPC */

/* Define if you want to use the standard Unix plot library.  */
/* #undef UNIXPLOT */

/* Define to the version of the distribution.  */
#define VERSION "beta347pl6"

/* Define if you are using the X11 window system.  */
#define X11 1

/* Define to `long' if <sys/types.h> doesn't define.  */
/* #undef time_t */

/* Define if you have the atexit function.  */
#define HAVE_ATEXIT 1

/* Define if you have the bcopy function.  */
#define HAVE_BCOPY 1

/* Define if you have the bzero function.  */
#define HAVE_BZERO 1

/* Define if you have the erf function.  */
#define HAVE_ERF 1

/* Define if you have the erfc function.  */
#define HAVE_ERFC 1

/* Define if you have the gamma function.  */
#define HAVE_GAMMA 1

/* Define if you have the getcwd function.  */
#define HAVE_GETCWD 1

/* Define if you have the index function.  */
#define HAVE_INDEX 1

/* Define if you have the lgamma function.  */
#define HAVE_LGAMMA 1

/* Define if you have the memcpy function.  */
#define HAVE_MEMCPY 1

/* Define if you have the memset function.  */
#define HAVE_MEMSET 1

/* Define if you have the on_exit function.  */
/* #undef HAVE_ON_EXIT */

/* Define if you have the pclose function.  */
#define HAVE_PCLOSE 1

/* Define if you have the popen function.  */
#define HAVE_POPEN 1

/* Define if you have the rindex function.  */
#define HAVE_RINDEX 1

/* Define if you have the setvbuf function.  */
#define HAVE_SETVBUF 1

/* Define if you have the sleep function.  */
#define HAVE_SLEEP 1

/* Define if you have the snprintf function.  */
#define HAVE_SNPRINTF 1

/* Define if you have the strchr function.  */
#define HAVE_STRCHR 1

/* Define if you have the strerror function.  */
#define HAVE_STRERROR 1

/* Define if you have the strncasecmp function.  */
#define HAVE_STRNCASECMP 1

/* Define if you have the strnicmp function.  */
/* #undef HAVE_STRNICMP */

/* Define if you have the strrchr function.  */
#define HAVE_STRRCHR 1

/* Define if you have the strstr function.  */
#define HAVE_STRSTR 1

/* Define if you have the sysinfo function.  */
#define HAVE_SYSINFO 1

/* Define if you have the tcgetattr function.  */
#define HAVE_TCGETATTR 1

/* Define if you have the <errno.h> header file.  */
#define HAVE_ERRNO_H 1

/* Define if you have the <float.h> header file.  */
#define HAVE_FLOAT_H 1

/* Define if you have the <libc.h> header file.  */
/* #undef HAVE_LIBC_H */

/* Define if you have the <limits.h> header file.  */
#define HAVE_LIMITS_H 1

/* Define if you have the <locale.h> header file.  */
#define HAVE_LOCALE_H 1

/* Define if you have the <malloc.h> header file.  */
#define HAVE_MALLOC_H 1

/* Define if you have the <math.h> header file.  */
#define HAVE_MATH_H 1

/* Define if you have the <sgtty.h> header file.  */
#define HAVE_SGTTY_H 1

/* Define if you have the <stdlib.h> header file.  */
#define HAVE_STDLIB_H 1

/* Define if you have the <string.h> header file.  */
#define HAVE_STRING_H 1

/* Define if you have the <sys/bsdtypes.h> header file.  */
/* #undef HAVE_SYS_BSDTYPES_H */

/* Define if you have the <sys/select.h> header file.  */
#define HAVE_SYS_SELECT_H 1

/* Define if you have the <sys/socket.h> header file.  */
#define HAVE_SYS_SOCKET_H 1

/* Define if you have the <sys/stat.h> header file.  */
#define HAVE_SYS_STAT_H 1

/* Define if you have the <sys/systeminfo.h> header file.  */
#define HAVE_SYS_SYSTEMINFO_H 1

/* Define if you have the <sys/time.h> header file.  */
#define HAVE_SYS_TIME_H 1

/* Define if you have the <sys/types.h> header file.  */
#define HAVE_SYS_TYPES_H 1

/* Define if you have the <sys/utsname.h> header file.  */
#define HAVE_SYS_UTSNAME_H 1

/* Define if you have the <termios.h> header file.  */
#define HAVE_TERMIOS_H 1

/* Define if you have the <time.h> header file.  */
#define HAVE_TIME_H 1

/* Define if you have the <values.h> header file.  */
#define HAVE_VALUES_H 1
